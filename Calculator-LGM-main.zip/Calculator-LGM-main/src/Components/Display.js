import React from "react"
export default function Display({answer}){
    return (
        <div className="display">{answer}</div>
    )
}