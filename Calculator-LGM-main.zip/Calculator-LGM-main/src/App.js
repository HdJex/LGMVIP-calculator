import './App.css';
import Calculator from './Components/Calculator';

function App() {
  return (
    <div>
       <h1>CALCULATOR</h1>
      <Calculator />
    </div>
  );
}

export default App;
